list = []
n=int(input("Enter no. of terms you want to add in a list - "))
for i in range(n):
    list.append(input())
print(list)