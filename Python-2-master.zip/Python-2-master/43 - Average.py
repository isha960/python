def average(a,b,c,d,e):
    return (a+b+c+d+e)/5;

a=float(input("Enter 1st No. - "))
b=float(input("Enter 2nd No. - "))
c=float(input("Enter 3rd No. - "))
d=float(input("Enter 4th No. - "))
e=float(input("Enter 5th No. - "))
avg=average(a,b,c,d,e)
print("Average is - ",avg)