tuple = ('a','b','c','d','e')
print(tuple)
