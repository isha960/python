dict = {'Name':'Mark','Age':26,'Roll No.':'CS150'}
print(dict)
dict['Age']=27
del dict['Roll No.']
print(dict)
dict['Address']='India'
print(dict)