list=[]
n=int(input("Enter no. of elements you want to add - "))
for i in range(n):
    list.append(input())
print(list)
tuple(list)
print(list)