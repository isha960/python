text = input(" Enter any Text - ")
print(" You entered - ",text)
