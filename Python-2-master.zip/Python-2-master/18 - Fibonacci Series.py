n=int(input("Enter no. of terms you want to print - "))
a=int(0)
b=int(1)
for i in range(n):
    print(a)
    temp=a
    a=a+b
    b=temp