set={1,2,3,4,5}
print(set)
n=int(input("Enter no. of items you want to add - "))
for i in range(n):
    a=input("Enter value to be inserted - ")
    set.add(a)
print(set)