dict={'x':45,'y':68,'z':27}
sum=0
for i in dict:
    sum+=dict[i]
print("Sum of Values is - ",sum)