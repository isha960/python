tuple=("Hello",4.5,'*',60)
print(tuple)
count=0
for i in tuple:
    count+=1
print("Tuple Lenght - ",count)
print("Using inbuild function - ",len(tuple))