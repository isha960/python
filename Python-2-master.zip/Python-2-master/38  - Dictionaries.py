dict = {'Name':'Mark','Age':26,'Roll No.':'CS150'}
print(dict)
print(dict['Name'])
print(dict.get('Roll No.'))