tuple = ('a','b','c','d','e')
print(tuple[4])
print(tuple[-5])
print(tuple[1:4])