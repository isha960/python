a = int(input("Enter 1st No. - "))
b = int(input("Enter 2nd No. - "))
if(a==b):
    print("Equal.")
else:
    print("Not Equal.")
