a=int(input("Enter any No. - "))
for i in range(1,11):
    print(a," * ",i," = ",a*i)