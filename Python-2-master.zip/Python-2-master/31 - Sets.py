set1={1,2,3,4,5}
mixset={'hello',1,5.7,'&'}
set2={1,1,1,2,2,3}
print(set1)
print(mixset)
print(set2)