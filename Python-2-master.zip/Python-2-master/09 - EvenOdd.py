a=int(input("Enter any No. - "))
if(a%2==0):
    print("Even.")
else:
    print("Odd.")
