list = [1,2,3,4,5]
print(list)
list.append(list[4]+list[1])
list.pop(3)
print(list)
list.clear()
print(list)