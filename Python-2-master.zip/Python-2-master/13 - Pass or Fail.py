pas=float(input("Enter Passing Marks - "))
mark=float(input("Enter Marks Obtained - "))
if(mark>=pas):
    print("Pass.")
else:
    print("Fail.")