a=int(input("Enter 1st no. - "))
b=int(input("Enter 2nd no. - "))
print("Before Swapping - ")
print("A = ",a,"\t\tB = ",b)
c=a
a=b
b=c
print("After Swapping - ")
print("A = ",a,"\t\tB = ",b)
